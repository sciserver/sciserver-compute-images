Requirements to use the gbmrsp code:

1. The DRM database needs to be installed. The current version can be downloaded
from http://public.lanl.gov/mkippen/gbmsim/team under Test Data Exchange
 200811: DRM Database002 (272 points)

2. cfitsio must be installed 
(The cfitsio library that comes with Ftools can be used)

Note, if the cfitsio library you have has either the extension ".so" (link)
or ".dylib" (MacOS) and the library is not in the standard path, you'll need to
add extra steps before compiling the code:

  (i) If the library has a version number in its name, cd to that directory and
  create a link in the same directory without the version number
  cd <path to library>
  Mac OS:
  ln -s libcfitsio_3.03.dylib libcfitsio.dylib
  Linux:
  ln -s libcfitsio_3.03.so libcfitsio.so
  
  (ii) Add -L<path to library> to the file link_gbmrsp 
  
  (iii) At runtime, 
  Mac OS:
  export DYLD_LIBRARY_PATH=<path to library>:$DYLD_LIBRARY_PATH
  Linux:
  export LD_LIBRARY_PATH=<path to library>:$LD_LIBRARY_PATH


3. gfortran must be installed. 

To compile the code, cd to gbmrsp_release/code and type
 ./link_gbmrsp_gfortran to compile using
gfortran.
(note: the file link_gbmrsp_gfortran assumes the environment variable HEADAS points to the cfitsio location. ).
This will make an executable in the gbmrsp_release directory.

4. To run the code directly, edit the namelist file gbmrsp.nml.

5. ***New for v1.8 - the environment variable GBMRSP_NML must be set to point to the namelist file***

The namelist contains the following inputs:
New inputs for v1.8 are marked with **new for v1.8**. Types for each input have
been added.

debug - (integer) -controls verbosity of the code. Most users want = 0.
detector - (integer) - the FSW detector number, 0-11 for NAI and 12-13 for BGO.
triflag - Will usually =0. This is used if the response database is regenerated
          and the user wishes to regenerate the triangulation information for a
	  new quasi-grid of sky locations. 	  
tripath - (string) - the path to the triangulation info fits file (Note, this 
	  file for the current drm database is included with this release in the
	  input subdirectory.)
trifile - (string) the name of the fits file containing the triangulation info. The file
  for the above listed drm database is:'InitialGBMDRM_triangleinfo_db001.fits' 
  and is in the inputs subdirectory of this release.  The sky grid is the same 
  for DRMdb00 and DRMdb002, so the same trifile can be used for both.
src_ra, src_dec  - (float) J2000 position for the source. This is written to 
	file headers.   
drmdbpath - (string) - the path to the drm database 
leaf_ver - (string) the version number for the leaf files in the drm database,
        e.g 'v10' **new for v1.7**
nobins_in - (integer) the number of input photon energy edges desired in the DRM
nobins_out - (integer) the number of output channel energy edges desired in the DRM
ebin_edge_in - (float) the actual input photon edges (need to have nobins_in+1)
ebin_edge_out - (float) the actual output channel edges (need to have 
	nobins_out+1)
npos - (integer) the number of source positions in s/c coordinates for which 
	responses are to be generated.
src_az - (float)- the source position(s) in s/c azimuth (npos of them)
src_el - (float)- the source position(s) in s/c/ elevation (npos of them)
geo_az, geo_el - (float) - the Earth position in s/c coordinates - these should
	 correspond to each source position
tstart, tstop - (float) - start/stop times in seconds since MJDREF corresponding
	 to each source s/c position. (These are converted to year-mon-day 
	 values and written to file headers.)
trigger_sec - (float) - time of trigger in seconds since MJDREF. (Written to 
	file headers.)
energy_calib_scheme -(string)- The name of the energy calibration scheme used to make
 EBOUNDS array. (written to EBOUNDS extension header).**new for v1.7**
lut_filename - (string)- File name for LUT used in construction of the EBOUNDS 
	array.(written to EBOUNDS extension header).**new for v1.7**
gain_cor - (float) - the gain correction factor applied to the energy edges. 
  (written to EBOUNDS extension header).**new for v1.7**
object_class - written to fits file header 
matrix_type - 0 (direct), 1 (scattered), or 2 (summed). All 3 options are now 
 implemented.
atscat_path - path to atmospheric scattering database, written to fits file 
  header. The current file is located in the inputs subdirectory.
atscat_file - file containing atmospheric scattering database, written to fits
 file extension header if used. The current file is
 "test_atscat_file_preeinterp_db002.fits" 
use_coslat_corr = 1 (yes) or 0 = (no). If = 1, the atmospheric scattering matrix
  is multiplied by abs(cos(lat)) where lat is the angle between the source and
  geocenter directions. Test parameter. Most users will want use_coslat_corr=1.
   **new for v1.7**. 
read_one_drm - = 0 (no) = 1 (yes). If = 1, a specific drm file is read in, 
 instead of interpolating from the database. The response database is still used
 for atmospheric scattering calculations if matrix_type=1 or 2. User should be 
 very cautious using this option, because it reads in the requested matrix and
 assumes that the detector, src_az, and src_el are set correctly in the namelist
 for that matrix.
one_drm_path - path to specific drm file
one_drm_file - name of specific drm file.
calling_code - name and version number of calling code (e.g. SA_GBM_RSP_Gen.pl-v1.8) - NO spaces! **new for v1.8**

Release notes v2.0 (release) Nov 3, 2011 - increased the allowable number of photon edges 
(e_bin_edge_in) to 3000 to allow up to 2999 input photon bins(nobins_in = 2999). CCR#379
Increased allowable length of output rsp file name from 120 to 240 characters.
Added check that input photon bin edges and channel energy edges are strictly increasing - CCR #203



Release notes v1.9
C gbmrsp v1.9 (release) December 29, 2009 - added DET_ANG and GEO_ANG keywords
C  to SPECRESP MATRIX extension headers. DET_ANG = angle between source and 
C  detector normal. GEO_ANG = angle between geocenter and detector normal.
C  For the BGOs that don't exactly have detector normals, I used the +x and -x
C  axes for BGO 0 and 1 respectively. Also, I corrected the comments in the
C  SPECRESP MATRIX headers for SRC_AZ, SRC_EL, GEO_AZ, and GEO_EL - they now
C correctly say that these quantities are in SPACECRAFT coordinates (instead of
C detector coordinates as they previously said.)



Release notes v1.81: 
C gbmrsp v1.81 (release) October 13, 2009 - tiny bug fix that only affects 
C  read_one_drm=1 special mode (no effect for most users). The order of maxen
C and maxchan was reversed in the call to readpixeedges from read_single_drm.
C This bug was present in versions prior  v1.8, but had no effect because
C maxen=maxchan. In v1.8, maxen was not equal to maxchan, so read_one_drm=1 mode
C produced matrices with only NaN values and zeros.

Release notes v1.8:
C gbmrsp v1.8 (release) September 28, 2009 - contains changes listed under
C  gbmrsp v1.8pr and gbmrsp v1.8rc. (max photon energies is 200) .
C  This version should close CCR #177, #192, #193.
C
C gbmrsp v1.8rc (release candidate) September 16, 2009 CAWH
C (1) Another bug was found in sec_to_date.f that caused the seconds to be negative. This crashed
C  later fits utility code which caused fewer than expected matrices to be written to the file.
C (2) The limit on the # of photon energy edges was set back to 200 (it was 300 in 1.8pr), because
C   no improvement was apparent in fits to grb090902b when more than 199 edges were used.
C (3) Now the environment variable GBMRSP_NML must be set by the user to point 
C   to the namelist file.
C
C gbmrsp v1.8pr (prerelease)
C Major changes:
C A bug of omission was found - the responses needed to be integrated over
C photon bins. To do this, the code now computes interpolated values for the
C response at each requested photon bin and at the logarithmic center of each 
C bin. Each bin is then integrated over 3 points (lower edge, logarithmic
C center, and upper edge) using the trapezoidal rule. CCR#192
C Minor changes:
C (1) echan_integrator.f code was replaced with echan_integrator.REV.f - the code
C was cleaned up by Michael Briggs to make it more readable. 
C (2) sec_to_date.f was changed so that it no longer outputs values of 60
C seconds in month-day-hours-min-secs keywords in the headers.
C   CCR #177
C (3) CCR #193 - calling_code (string) was added to the namelist file. This is
C  expected to contain the calling code name and version number and is appended
C  to the CREATOR keyword in the fits file. In previous versions the CREATOR
C  keyword was hardcoded to GBMRespGen (doesn't exist). This was corrected to be
C  GBMRSP. 

Release notes v1.7
C gbmrsp v1.7 2008-November-24
C Major Change:
C (1) New approach for atmospheric scattering, where database is
C     pre-interpolated in energy to match photon edges for the GBM leaf drms
C     DRMs. Then the appropriate atmospheric scattering matrix is matrix
C     multiplied by the direct matrix for that direction, after each direct
C     matrix has been uncompressed. The scattered matrix is then interpolated
C     over the user photon energies.
C     Routines changed: atscat_diff_calc_norm.f, gbmrsp.f
C     Routines added: read_atscat_alldbs.f, get_atscatdb_dimensions.f,
C		      atscat_highres_ephoton_interpolator.f
C     Routines deleted: read_atscat.f, samp_calc.f
C Additions: 
C (1) Audit trail information for LUTs has been added to the namelist and 
C      EBOUNDS extension of the output rsp files.
C (2) The version number for the DRM leaf files has been added to the namelist
C     and is now passed to sky_interp and atscat_diff_calc_norm to be used by
C     parse_drm_filename. 
C (3) Trap added to highres_ephoton_interpolator.f to handle cases where 
C     desired energy and original energy are basically equal but not quite.
C (4) energy_integrator.f was replaced with echan_integrator.f.
C      Energy_interpolator.f interpolated over both the ephoton and echannel
C      energies. Since this step is done in highres_ephoton_integrator, it was
C      redundant and was removed.
C (5) A bug was fixed in calc_sphere_dist.f. It was calculating incorrect
C      distances when the elevation angle was large.
  

Release notes: v1.6
C *** gbmrsp v1.6 2008-September-3
C Major changes:
C Atmospheric scattering was not working properly. Extensive testing revealed that
C (1) The definition of phi in Geoff's database was 180 degrees of what this code
C expected and (2) Geoff's database predicted maximum scattering near latitude = 90
C deg, which disagrees with BATSE extrapolations (3) The scattering calculation
C predicted way too many counts at all angles. 
C Problem (1) was addressed by changing the definition of phi_edge in gbmrsp.f
C Problem (2) was addressed by multiplying the input atmospheric scattering matrix by
C cos(latitude) where latitude is defined as the angle between the source and the
C geocenter. Latitude is 0 for a source that is directly overhead and 90 near the
C horizon.
C Problem (3) was addressed by the following changes:
C (a) In atscat_diff_matrix.f, the input direct matrix is no longer divided by energy
C     i.e. the units were changed from cm^2/keV to cm^2 because cm^2 is the desired
C     units later in the code.
C (b) In gbmrsp.f the scattered matrix is no longer multiplied by energy. Previously 
C this step was to convert the units of the scattered matrix back to cm^2.
C Minor changes:
C (1) Added debug=-1 option. This turns off all messages to the screen except error
C messages.
C (2) Increased the maximum number of responses per file from 100 to 300.
C (3) In atscat_diff_matrix.f - this now uses the closest drm from Marc's database for
C the scattering calculation. No spatial interpolation is done.
C (4) In geocords.f - the vectors gx,gy(part of conversion from scattering database
C     coordinates to spacecraft coordinates),gz (geocenter direction),and 
C     sl(source direction) are now normalized

Release notes: v1.5
gbmrsp v1.5 2008-April-15
Specific changes:
1. An additional interpolation step was added (highres_ephoton_interpolator.f)
that smoothly interpolates over the input energies using the compressed matrices
with the photopeaks already aligned. This now allows the use of higher 
resolution photon energies than were used in the database.
2. The code can now be compiled with either gfortran or g77.
3. A trap was added to prevent input (photon) energies below the minimum or
above the maximum values used in the database matrices.

Release notes: v1.4 - this was never a full release, only a test version. 
Change 1 in v1.5 was implemented in this version, but problems with array
dimensioning were discovered that prevented proper operation if compiled with
gfortran. These are fixed in v1.5

Release notes: v1.3
gbmrsp v1.3 2008-March-14 implemented atmospheric scattering
Specific changes 
1. matrix_type =0 (direct), 1(scattered), and 2(summed = direct+Scattered) now all
 supported.
2. Added call to read_atscat to read in atscat database if desired
3. Added call to atscat_diff_calc_norm - this code does the atmospheric scattering
 calculation by convolving results from the atmospheric scattering database for 
 several scattering directions with the direct detector response matrix for each 
 direction to create an atmospheric scattering matrix.
4. Added variables read_one_drm = 0 (no) or =1 (yes), one_drm_path, and one_drm_file
  to namelist. This allows the option of inputing a specific drm instead of
 interpolating from the database. Note, this option needs to be used with caution,
 because values of detector, src_az, and src_el are used directly from the
 namelist input without checks to see if they are compatible with the input
 matrix.
